package models

type AnalyticsSprint struct {
	
}